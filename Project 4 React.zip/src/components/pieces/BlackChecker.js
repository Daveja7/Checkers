import blackChecker from '../../assets/black-checker.svg'

function BlackChecker(props) {
    return (
        <img src={blackChecker} alt={'A black checker.'} className={'piece'} />
    )
}

export default BlackChecker